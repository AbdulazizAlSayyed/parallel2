#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


// Function to calculate small primes up to sqrt(n)
void calculate_small_primes(int limit, int **small_primes, int *count) {
    char *is_prime = (char *)malloc((limit + 1) * sizeof(char));
    for (int i = 2; i <= limit; i++) is_prime[i] = 1;

    for (int i = 2; i * i <= limit; i++) {
        if (is_prime[i]) {
            for (int j = i * i; j <= limit; j += i) {
                is_prime[j] = 0;
            }
        }
    }

    *count = 0;
    for (int i = 2; i <= limit; i++) {
        if (is_prime[i]) (*count)++;
    }

    *small_primes = (int *)malloc(*count * sizeof(int));
    int index = 0;
    for (int i = 2; i <= limit; i++) {
        if (is_prime[i]) (*small_primes)[index++] = i;
    }

    free(is_prime);
}

int main(int argc, char *argv[]) {
    MPI_Init(&argc, &argv);
    int rank, size, n, sqrt_n;
    int *small_primes = NULL;
    int small_primes_count = 0;

    double start_time, end_time, parallel_time, seq_time, speedup, efficiency;

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (rank == 0) {
        printf("Enter the upper limit n: ");
        scanf("%d", &n);

        // Calculate sqrt(n) for small primes
        sqrt_n = (int)sqrt((double)n);

        if (size == 1) {

            start_time = MPI_Wtime();


            char *is_prime = (char *)malloc((n + 1) * sizeof(char));
            for (int i = 2; i <= n; i++) is_prime[i] = 1;

            for (int i = 2; i * i <= n; i++) {
                if (is_prime[i]) {
                    for (int j = i * i; j <= n; j += i) {
                        is_prime[j] = 0;
                    }
                }
            }


            end_time = MPI_Wtime();
            seq_time = end_time - start_time;

            printf("Primes up to %d:\n", n);
            for (int i = 2; i <= n; i++) {
                if (is_prime[i]) printf("%d ", i);
            }
            printf("\n");
            free(is_prime);
            MPI_Finalize();
            return 0;
        } else {
            
            calculate_small_primes(sqrt_n, &small_primes, &small_primes_count);
        }
    }


    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&small_primes_count, 1, MPI_INT, 0, MPI_COMM_WORLD);


    start_time = MPI_Wtime();


    if (rank != 0) {
        small_primes = (int *)malloc(small_primes_count * sizeof(int));
    }
    MPI_Bcast(small_primes, small_primes_count, MPI_INT, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        for (int i = 2; i <= n; i++) {
            MPI_Send(&i, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
        }
        int terminator = -1;
        MPI_Send(&terminator, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
    } else {
        int num;
        while (1) {
            MPI_Recv(&num, 1, MPI_INT, rank - 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            if (num == -1) {
                if (rank < size - 1) MPI_Send(&num, 1, MPI_INT, rank + 1, 0, MPI_COMM_WORLD);
                break;
            }

            int is_prime = 1;
            for (int i = 0; i < small_primes_count; i++) {
                if (num % small_primes[i] == 0 && num != small_primes[i]) {
                    is_prime = 0;
                    break;
                }
            }

            if (is_prime) {
                if (rank < size - 1) {
                    MPI_Send(&num, 1, MPI_INT, rank + 1, 0, MPI_COMM_WORLD);
                } else {
                    printf("%d is prime\n", num);
                }
            }
        }
    }


    end_time = MPI_Wtime();
    parallel_time = end_time - start_time;


    if (rank == 0) {
        if (size > 1) {
            speedup = seq_time / parallel_time;
            efficiency = speedup / size;
            printf("### Parallel Results ###\n");
            printf("The time taken on pipelined approach is %f seconds\n", parallel_time);
            printf("### Sequential Results ###\n");
            printf("The time taken on sequential approach is %f seconds\n", seq_time);
            printf("The speedup factor is %f\n", speedup);
            printf("The efficiency is %f\n", efficiency);
        }
    }
    
    if (small_primes) free(small_primes);
    MPI_Finalize();
    return 0;
}
